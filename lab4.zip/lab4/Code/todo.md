A-18：目前不报错，应该报15 at line 4 已定位843

E-2：多报了type 3 at line 25，少报了type 14 at line 35

E-3：报成了type 6 at line 23，应该是type 5 at line 23 已定位 已定位